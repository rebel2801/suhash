import 'package:app1/models/weather_model.dart';
import 'package:app1/services/weather_service.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class WeatherPage extends StatefulWidget {
  const WeatherPage({Key? key}) : super(key: key);

  @override
  State<WeatherPage> createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  // api key
  final _weatherService =
      WeatherService('f14f3ce1977c281c734dff891080454b');
  Weather? _weather;

  // fetch weather
  _fetchWeather() async {
    // get the current city
    String cityName = await _weatherService.getCurrentCity();

    // get weather for city
    try {
      final weather = await _weatherService.getWeather(cityName);
      setState(() => _weather = weather);
    }

    // handle errors
    catch (e) {
      print(e);
    }
  }

  // initial state
  @override
  void initState() {
    super.initState();
    // fetch weather on startup
    _fetchWeather();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // city name
            Text(
              _weather?.cityName ?? "loading city..",
              style: TextStyle(color: Colors.white), // Set text color to white
            ),
            // animation
            Lottie.asset('assets/sunny1.json'),
            // temperature
            Text(
              "Temperature : ${_weather?.temperature.round()}°C",
              style: TextStyle(color: Colors.white), // Set text color to white
            ),
          ],
        ),
      ),
    );
  }
}

